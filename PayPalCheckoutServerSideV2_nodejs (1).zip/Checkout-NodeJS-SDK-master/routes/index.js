const https = require('https');
const session = require('express-session');
const express = require('express');
const basic_functions = require('../common/library/basic_functions.js');
const router = express.Router();
router.use(session({secret: 'ssshhhhh',saveUninitialized: true,resave: true}));
router.use(express.urlencoded({
  extended: true
}));
let sess;
//Index
router.get('/', (req, res) => {
  sess = req.session;
  sess.order_id;
  res.sendFile(__dirname +  '/html/index.html');
});
//Begin Assets Endpoints
router.get('/js/config.js', (req, res) => {
  res.sendFile(__dirname +  '/html/js/config.js');
});
router.get('/img/camera.jpg', (req, res) => {
  res.sendFile(__dirname +  '/html/img/camera.jpg');
});
router.get('/pages/shipping', (req, res) => {
  res.sendFile(__dirname +  '/html/pages/shipping.html');
});
router.get('/pages/success', (req, res) => {
  res.sendFile(__dirname +  '/html/pages/success.html');
});
//Helper Functions
random_number = () => {
  return Math.floor(100000 + Math.random() * 900000);
}
//Begin API Endpoints
//Create Order API Endpoint
/* Note: We are not uploading anything but the client-side formData class will always send in Multipart/form-data instead of application/x-www-form-urlencoding so using Multer to parse those body params */
router.post('/api/createOrder', (req, res) => {
  //Build the PayPal object to create order and populate with POST params from website
  let item_obj = {
    "intent" : "CAPTURE",
    "application_context" : {
        "return_url" : req.body.return_url,
        "cancel_url" : req.body.cancel_url
    },
    "purchase_units" : [ 
        {
            "reference_id" : "PU1",
            "description" : "Camera Shop",
            "invoice_id" : "INV-CameraShop-" + random_number(),
            "custom_id" : "CUST-CameraShop",
            "amount" : {
                "currency_code" : req.body.currency,
                "value" : req.body.total_amt,
                "breakdown" : {
                    "item_total" : {
                        "currency_code" : req.body.currency,
                        "value" : req.body.item_amt
                    },
                    "shipping" : {
                        "currency_code" : req.body.currency,
                        "value" : req.body.shipping_amt
                    },
                    "tax_total" : {
                        "currency_code" : req.body.currency,
                        "value" : req.body.tax_amt
                    },
                    "handling" : {
                        "currency_code" : req.body.currency,
                        "value" : req.body.handling_fee
                    },
                    "shipping_discount" : {
                        "currency_code" : req.body.currency,
                        "value" : req.body.shipping_discount
                    },
                    "insurance" : {
                        "currency_code" : req.body.currency,
                        "value" : req.body.insurance_fee
                    }
                }
            },
            "items" : [{
                "name" : "DSLR Camera",
                "description" : "Black Camera - Digital SLR",
                "sku" : "sku01",
                "unit_amount" : {
                    "currency_code" : req.body.currency,
                    "value" : req.body.item_amt
                },
                "quantity" : "1",
                "category" : "PHYSICAL_GOODS"
            }]
        }
    ]
  };
  //If order details contain shipping, append shipping and preferences
  if (req.body.line1 !== undefined) {
    item_obj.application_context.shipping_preference = "SET_PROVIDED_ADDRESS";
    item_obj.application_context.user_action = "PAY_NOW";
    item_obj.purchase_units[0].shipping = {
      "address" : {
        "address_line_1": req.body.line1,
        "address_line_2": req.body.line2,
        "admin_area_2": req.body.city,
        "admin_area_1": req.body.state,
        "postal_code": req.body.zip,
        "country_code": req.body.countrySelect
      }
    };
  }
  basic_functions.create_order(item_obj).then((response) => {
    console.log("response.id: " + response.id);
    sess.order_id = response.id;
    res.send(response);
  });
});
//Capture Order API Endpoint
router.post('/api/captureOrder', (req, res) => {
  basic_functions.capture_order(sess.order_id).then((response) => {
    res.send(response);
  });
});
//POST the Get Order API Endpoint
router.post('/api/getOrderDetails', (req, res) => {
  basic_functions.get_order_details(sess.order_id).then((response) => {
    res.send(response);
  });
});
//Get Order API Endpoint
router.get('/api/getOrderDetails', (req, res) => {
  basic_functions.get_order_details(sess.order_id).then((response) => {
    res.send(response);
  });
});
//Patch Order API Endpoint
router.post('/api/patchOrder', (req, res) => {
  new_order_details = {
    "patch_details": [{
      "op" : "replace",
      "path" : "/purchase_units/@reference_id==\'PU1\'/amount",
      "value" : {
        "currency_code" : req.body.currency,
        "value" : parseInt(req.body.total_amt) + parseInt(req.body.updated_shipping) - parseInt(req.body.current_shipping),
        "breakdown" : {
          "item_total" : {
            "currency_code" : req.body.currency,
            "value" : req.body.item_amt,
          },
          "shipping" : {
            "currency_code" : req.body.currency,
            "value" : req.body.updated_shipping
          },
          "tax_total" : {
            "currency_code" : req.body.currency,
            "value" : req.body.tax_amt
          },
          "shipping_discount" : {
            "currency_code" : req.body.currency,
            "value" : req.body.shipping_discount
          },
          "handling" : {
            "currency_code" : req.body.currency,
            "value" : req.body.handling_fee
          },
          "insurance" : {
            "currency_code" : req.body.currency,
            "value" : req.body.insurance_fee
          }
        }
      }       
    }],
    "order_id": sess.order_id
  };
  basic_functions.patch_order_details(new_order_details).then((patch_request_response) => {
    res.send({ http_code: patch_request_response });
  });
});

module.exports = router;