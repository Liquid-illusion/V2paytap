const https = require('https');
const config = require('../config/config.json');
const get_oauth = () => {
  return new Promise(resolve => {
      
      const data = 'grant_type=client_credentials';

      const options = {
        hostname: 'api.' + (config.environment === 'sandbox' ? 'sandbox.' : '') + 'paypal.com',
        port: 443,
        path: '/v1/oauth2/token',
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Content-Length': data.length,
          'Authorization': 'Basic ' + Buffer.from((config.environment === 'sandbox' ? config.sandbox_client_id : config.production_client_id) + ':' + (config.environment === 'sandbox' ? config.sandbox_secret : config.production_secret)).toString('base64')
        }
      }
      const my_callback = function(res){

        let str='';

        res.on('data',function(chunk){
            str+=chunk;
        });

        res.on('end',function(){
            obj=JSON.parse(str);
            resolve(obj);
        });
      }
      let request = https.request(options, my_callback);
      request.write(data);
      request.end();

    });
};
const get_access_token = () => {
  return new Promise(resolve => {
    get_oauth().then((response) => {
      resolve(response.access_token);
    });
  });
};
const create_order = (item_obj) => {
  return new Promise(resolve => {
    get_access_token().then((access_token) => {
  
    const options = {
      hostname: 'api.' + (config.environment === 'sandbox' ? 'sandbox.' : '') + 'paypal.com',
      port: 443,
      path: '/v2/checkout/orders',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + access_token
      }
    }
    const my_callback = function(res){

      let str='';

      res.on('data',function(chunk){
          str+=chunk;
      });

      res.on('end',function(){
          obj=JSON.parse(str);
          resolve(obj);
      });
    }
    let request = https.request(options,my_callback);
    request.write(JSON.stringify(item_obj));
    request.end();

  });

  });
};
const get_order_details = (order_id) => {
  return new Promise(resolve => {
    get_access_token().then((access_token) => {
  
    const options = {
      hostname: 'api.' + (config.environment === 'sandbox' ? 'sandbox.' : '') + 'paypal.com',
      port: 443,
      path: '/v2/checkout/orders/' + order_id,
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + access_token
      }
    }
    const my_callback = function(res){

      let str='';

      res.on('data',function(chunk){
          str+=chunk;
      });

      res.on('end',function(){
          obj=JSON.parse(str);
          resolve(obj);
      });
    }
    let request = https.request(options,my_callback);
    request.end();

  });

  });
};
const patch_order_details = (new_order_details) => {
  return new Promise((resolve, reject) => {
    get_access_token().then((access_token) => {
      patch_details = new_order_details.patch_details;
      order_id = new_order_details.order_id;
      const options = {
        hostname: 'api.' + (config.environment === 'sandbox' ? 'sandbox.' : '') + 'paypal.com',
        port: 443,
        path: '/v2/checkout/orders/' + order_id,
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + access_token
        }
      }
      let request = https.request(options, function (response) {
        resolve(response.statusCode);
      });
      request.write(JSON.stringify(patch_details));
      request.end();
  });
});

};
const capture_order = (order_id) => {
  return new Promise(resolve => {
    get_access_token().then((access_token) => {
    const options = {
      hostname: 'api.' + (config.environment === 'sandbox' ? 'sandbox.' : '') + 'paypal.com',
      port: 443,
      path: '/v2/checkout/orders/' + order_id + '/capture',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + access_token,
        'return': 'representation',
        'PayPal-Partner-Attribution-Id': 'PP-DemoPortal-Checkout-NodeJS-SDK'
      }
    }
    const my_callback = function(res){
      let str='';
      res.on('data',function(chunk){
          str+=chunk;
      });
      res.on('end',function(){
          obj=JSON.parse(str);
          resolve(obj);
      });
    }
    let request = https.request(options,my_callback);
    request.end();
    });
  });
};

module.exports = {
  get_access_token: get_access_token,
  get_oauth: get_oauth,
  create_order: create_order,
  get_order_details: get_order_details,
  patch_order_details: patch_order_details,
  capture_order: capture_order
};