# PayPal Checkout Server-side NodeJS Demo - Using Orders v2 REST API with PayPal JavaScript SDK

## Prerequisites

1. Update [`common/config/config.json`](common/config/config.json) with your REST API credentials.
   If not updated, sandbox credentials are already pre-filled ready for use
2. Make sure you have installed NodeJS and NPM (https://nodejs.org/en/download/)

## Quick Start Demo

1. Place all files on your server, filename should be `Checkout-NodeJS-SDK-master.zip` and unzip the contents
2. Navigate into the node files directory `cd Checkout-NodeJS-SDK-master`
3. Update/install all the node files `npm i`
4. Run the project `node index`
   You will see the message:
   `Express is running on port 3000` (don't forget to add port 3000 to your URL)

## How the code works

- Click on 'PayPal Checkout’ button and see the experience. Additionally, you can click on "Proceed to Checkout" and see the guest checkout experience.
- In the guest checkout experience, the buyer country can be switched. When switched to one of Germany, Poland, Austria, Belgium, Netherlands, Italy and Spain, you will be able to choose the alternative payment methods offered in those countries. The shipping address will be pre-filled on the Shipping Information page for these countries. For all other countries not mentioned, the address has to be manually entered.
